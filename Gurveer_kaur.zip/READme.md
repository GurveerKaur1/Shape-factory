## Click me if you can

A shape factory made with JavaScript.

### Demo

Click [here]( https://gurveerkaur1.github.io/Shape-factory/) to check.



